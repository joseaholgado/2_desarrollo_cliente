"use strict";

//Función que borra el operando 1
function borrarOperador1(){
    num1='';
    pantallaAbajo.textContent = num1;
}
//Función que borra el operando 2
function borrarOperador2(){
    num2='';
    pantallaAbajo.textContent = num2;
}