"use strict";

function mostrar(resultado, opcionJugador, opcionComputadora) {
    mensaje.innerHTML = `Tu elegiste ${opcionJugador}, la computadora eligió ${opcionComputadora}. Resultado: ${resultado}`;
}