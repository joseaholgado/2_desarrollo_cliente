"use strict";
 
//Función que muestra el texto en minúscula
function minuscula(texto){
    let textoMinuscula = texto.toLowerCase();
    document.getElementById("texto").value = textoMinuscula;
} ;