"use strict";

//Función que muestra el texto en mayúsculas 
 function mayuscula(texto){
    let textoMayuscula = texto.toUpperCase();
    document.getElementById("texto").value = textoMayuscula;

    };