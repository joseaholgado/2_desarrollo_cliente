'use strict'


//funcion para las vidas
function drawLives() {
    ctx.font = "16px Arial";
    ctx.fillStyle = "#8B4950";
    ctx.fillText("Lives: "+lives, canvas.width-65, 20);
    }