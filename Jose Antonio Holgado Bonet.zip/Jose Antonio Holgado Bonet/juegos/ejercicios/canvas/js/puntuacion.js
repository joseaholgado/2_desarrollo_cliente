'use strict'

//funcion para la puntuacion
function drawScore() {
    ctx.font = "16px Arial";
    ctx.fillStyle = "#8B4950";
    ctx.fillText("Score: "+score, 8, 20);
    }