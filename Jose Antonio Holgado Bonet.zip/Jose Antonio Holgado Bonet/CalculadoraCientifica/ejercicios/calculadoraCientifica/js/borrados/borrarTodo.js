"use strict";
// Declara una función llamada 'borrarTodo'
function borrarTodo(){
     num1 = ''; 
     num2 = '';
     operador = '';
     pantallaAbajo.textContent = '';
     tieneOperador=false;
     
}