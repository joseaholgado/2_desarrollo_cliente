"use strict";

//Función para sacar la raíz cuadrada con el segundo operando
function raizCuadrada(num2) {
     
     let resu= Math.sqrt(num2);
     return resu;
}