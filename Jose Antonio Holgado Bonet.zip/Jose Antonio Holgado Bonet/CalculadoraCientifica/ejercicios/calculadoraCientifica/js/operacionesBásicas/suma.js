"use strict";

//Funcion que aplica la suma
function sumar(num1, num2) {
    return num1 + num2;
  }
  