"use strict";
//Funcion que realiza una multiplicacion
function multiplicar(num1, num2) {
    return num1 * num2;
  }