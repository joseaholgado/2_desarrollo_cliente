"use strict";
//Funcion que aplica la resta
function restar(num1, num2) {
    return num1 - num2;
  }