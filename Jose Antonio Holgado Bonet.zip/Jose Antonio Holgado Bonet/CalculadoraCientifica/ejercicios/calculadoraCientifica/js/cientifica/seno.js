"use strict";
// Función seno: calcula el seno del num1
function seno(){
    console.log(operador);
    
    return Math.sin(parseFloat(num1));
}