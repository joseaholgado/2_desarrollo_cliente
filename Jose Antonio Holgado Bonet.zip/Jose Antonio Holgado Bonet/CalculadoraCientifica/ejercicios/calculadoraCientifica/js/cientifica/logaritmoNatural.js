"use strict";
//Funcion que transforma la variable num1 en un logaritmo natural
function logaritmoNatural(){
    console.log(operador);
    
    return Math.log10(parseFloat(num1));
}