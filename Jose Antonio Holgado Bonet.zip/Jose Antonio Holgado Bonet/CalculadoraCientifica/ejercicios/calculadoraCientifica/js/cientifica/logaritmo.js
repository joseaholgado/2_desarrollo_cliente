"use strict";
//Funcion que transforma la variable num1 en un logaritmo 
function logaritmo(){
    console.log(operador);
    
    return Math.log(parseFloat(num1));
}