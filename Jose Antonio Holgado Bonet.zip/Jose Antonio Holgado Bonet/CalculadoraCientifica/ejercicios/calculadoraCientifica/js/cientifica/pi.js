"use strict";

//Funcion que cambia el valor por la constante PI
function pi(valor){
    console.log(valor);
    if (!tieneOperador) {
        return Math.PI;
    } else {
        return Math.PI;
    }
}