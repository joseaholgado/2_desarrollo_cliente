"use strict";

//Funcion que da un numero random hasta el 100
function random(){
    return Math.random(1000)*100;
}