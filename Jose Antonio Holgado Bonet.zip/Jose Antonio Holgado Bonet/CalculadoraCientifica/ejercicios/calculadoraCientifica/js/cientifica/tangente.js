"use strict";
// Función tangente: calcula la tangente de num1
function tangente(){
    
    return Math.tan(parseFloat(num1));
}