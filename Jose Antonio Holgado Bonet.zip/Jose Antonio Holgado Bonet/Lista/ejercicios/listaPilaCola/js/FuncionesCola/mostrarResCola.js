"use strict";

/**
 * Función para mostrar la representación de una cola en el HTML.
 */
export function mostrarResCola(estructura) {
    // Utiliza el método mostrarCola de la estructura para mostrar la cola en el HTML.
    estructura.mostrarCola();
}
