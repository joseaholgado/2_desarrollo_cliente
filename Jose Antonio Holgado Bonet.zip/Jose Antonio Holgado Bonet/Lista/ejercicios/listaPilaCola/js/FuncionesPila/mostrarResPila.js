"use strict";

/**
 * Función para mostrar la representación de una pila en la consola y actualizar elementos en el HTML.
 */
export function mostrarResPila(estructura) {
    // Utiliza el método mostrarPila de la estructura para mostrar la pila en la consola y actualizar elementos en el HTML.
    estructura.mostrarPila();
}