"use strict";

/**
 * Función para lavar una prenda de la pila de lavado.
 */
export function lavar(cesto) {
    // Utiliza el método desapilar de la pila para obtener la prenda que se va a lavar.
    return cesto.desapilar();
}





