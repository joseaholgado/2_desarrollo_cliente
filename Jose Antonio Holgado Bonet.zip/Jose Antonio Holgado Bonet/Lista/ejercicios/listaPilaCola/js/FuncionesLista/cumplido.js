"use strict";

/**
 * Función para marcar como cumplida la última tarea de una lista y eliminarla.
 */
export function cumplido(lista) {
    // Utiliza el método vaciar de la ListaTarea para marcar como cumplida y eliminar la última tarea.
    return lista.vaciar();
}
