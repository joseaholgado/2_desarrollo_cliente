"use strict";

/**
 * Función para mostrar la representación de una lista en el HTML.
 */
export function mostrarResLista(estructura) {
    // Utiliza el método mostrarResLista de la estructura para mostrar la lista en el HTML.
    estructura.mostrarResLista();
}
