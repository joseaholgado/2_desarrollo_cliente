"use strict"

const parrafo = document.getElementById("resultado");
parrafo.onclick = function() {
  alert('Este es mi primer script'); 
};

