"use strict"

alert("Bienvenido a mi página")
