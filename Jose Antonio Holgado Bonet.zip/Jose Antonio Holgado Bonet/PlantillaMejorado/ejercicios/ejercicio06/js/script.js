"use strict"

let persona = prompt("Dime tu nombre", "'Jose'");
function saludar() {
    alert("Hola " + persona);
}
function despedir() {
    alert("Adios " + persona);
}