"use strict"

let persona = prompt("Dime tu nombre", "'Jose'");
alert("Hola " + persona);